//
//  MainScene.h
//  SakuraFly
//
//  Created by Chenglin on 15-10-1.
//  Copyright (c) 2015年 Chenglin. All rights reserved.
//

#import "BaseScene.h"

@interface PrimaryScene : BaseScene

@property (nonatomic, assign) BOOL isGameStart;

@end
