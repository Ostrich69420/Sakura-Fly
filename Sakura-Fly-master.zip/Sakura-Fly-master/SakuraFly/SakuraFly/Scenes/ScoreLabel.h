//
//  ScoreLabel.h
//  birdgame
//
//  Created by Lin on 7/10/15.
//  Copyright (c) 2015 Chenglin. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface ScoreLabel : SKSpriteNode

@property(nonatomic, copy) NSString* finalPoint;

@end
