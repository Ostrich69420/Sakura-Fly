# Sakura Fly
#### Video Demo:  <https://youtu.be/Ld8swdOFNlA>
#### Description:
Sakura Fly is a mobile game which is a side-scroller where the player controls a paper airplane, attempting to fly between columns of red pipes while collecting traditional cherry blossom flowers. Each flower collected is 1 point and when connected to game centre you can enter into a leaderboard.
submit50 cs50/problems/2021/x/project

